﻿using System;

namespace First_task
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("За один запуск консоли можно проверить только одно упражнение. Номера упражнений: 1, 2, 3, 4.");
            Console.Write("Введите номер упражнения, который хотите проверить: ");

            try
            {
                int number = int.Parse(Console.ReadLine());
                if (number != 1 && number != 2 && number != 3 && number != 4)
                {
                    Console.WriteLine("Неверный номер упражнения!");
                    return;
                }

                Console.WriteLine("\nТестируем упражнение №" + number.ToString() + "...");

                if (number == 1)
                {
                    Console.Write("Представьтесь, пожалуйста: ");

                    string name = Console.ReadLine();
                    Console.WriteLine("Здравствуйте, " + name + ".");
                }
                else if (number == 2)
                {
                    Console.WriteLine("Введите 2 целых числа: ");

                    try
                    {
                        int a = int.Parse(Console.ReadLine());
                        int b = int.Parse(Console.ReadLine());

                        if (b == 0)

                        {
                            Console.WriteLine("Проказник! На ноль делить нельзя :)");
                            return;
                        }

                        float result = (float)a / (float)b;
                        Console.WriteLine("Результат деления: " + result.ToString() + ".");
                    }
                    catch
                    {
                        Console.WriteLine("Непредвиденная ошибка! Попробуйте ещё раз.");
                    }
                }
                else if (number == 3)
                {
                    Console.Write("Введите символ: ");

                    try
                    {
                        char symbol = Convert.ToChar(Console.ReadLine());

                        int newCode = (int)symbol + 1;
                        Console.WriteLine("Следующий символ: " + (char)newCode + ".");
                    }
                    catch
                    {
                        Console.WriteLine("Непредвиденная ошибка! Попробуйте ещё раз.");
                    }
                }
                else if (number == 4)
                {
                    Console.WriteLine("Введите целые коэффициенты( a, b, c ) квадратного уравнения( ax^2 + bx + c = 0 ): ");

                    try
                    {
                        int a = int.Parse(Console.ReadLine());
                        int b = int.Parse(Console.ReadLine());
                        int c = int.Parse(Console.ReadLine());

                        if (a == 0)
                        {
                            Console.WriteLine("Сударь, это вовсе не квадратное уравнение :)");
                            return;
                        }

                        int D = b * b - 4 * a * c;
                        if (D >= 0)
                        {
                            double sqrtD = Math.Sqrt(D);

                            double x1 = (-b + sqrtD) / (2 * a);
                            double x2 = (-b - sqrtD) / (2 * a);

                            if (x1 == x2) Console.WriteLine("Дискриминант равен 0. Корень единственный и равен " + x1.ToString() + ".");
                            else Console.WriteLine("Первый корень равен " + x1.ToString() + ", второй корень равен " + x2.ToString() + ".");
                        }
                        else
                        {
                            Console.WriteLine("Дискриминант отрицательный. Корней у уравнения с такими коэффициентами нет.");
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Непредвиденная ошибка! Попробуйте ещё раз.");
                    }
                }
            }
            catch
            {
                Console.WriteLine("Непредвиденная ошибка! Попробуйте ещё раз.");
            }
        }
    }
}