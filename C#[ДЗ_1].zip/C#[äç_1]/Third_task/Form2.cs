﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Third_task
{
    public partial class Form2 : Form
    {
        int maxScoreCount = 7;

        int playerSpeed = 5;
        int squareSpeedX = -2;
        int squareSpeedY = 2;

        Form1 form1;
        Player leftPlayer, rightPlayer;

        private void setPlayerCoords(int number, KeyEventArgs e)
        {
            if (form1.gamersCount == 2)
            {
                if (e.KeyCode == Keys.W) leftPlayer.directionY = -number;
                else if (e.KeyCode == Keys.S) leftPlayer.directionY = number;

                if (e.KeyCode == Keys.NumPad8) rightPlayer.directionY = -number;
                else if (e.KeyCode == Keys.NumPad2) rightPlayer.directionY = number;
            }
            else
            {
                if (form1.numberPosition == 0)
                {
                    if (e.KeyCode == Keys.W) leftPlayer.directionY = -number;
                    else if (e.KeyCode == Keys.S) leftPlayer.directionY = number;
                }
                else
                {
                    if (e.KeyCode == Keys.NumPad8) rightPlayer.directionY = -number;
                    else if (e.KeyCode == Keys.NumPad2) rightPlayer.directionY = number;
                }
            }
        }

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            form1 = (Form1)this.Owner;

            squareSpeedX *= form1.numberLevel;
            squareSpeedY *= form1.numberLevel;

            if (form1.gamersCount == 2)
            {
                leftPlayer = new Player(0, 0, false);
                rightPlayer = new Player(1, 0, false);
            }
            else
            {
                if (form1.numberPosition == 0)
                {
                    leftPlayer = new Player(0, 0, false);
                    rightPlayer = new Player(1, 0, true);

                    rightPlayer.directionY = playerSpeed;
                }
                else
                {
                    leftPlayer = new Player(0, 0, true);
                    rightPlayer = new Player(1, 0, false);

                    leftPlayer.directionY = playerSpeed;
                }
            }

            timer1.Enabled = true;
        }

        public void clearForm()
        {
            timer1.Enabled = false;

            squareSpeedX = 2;
            squareSpeedY = 2;

            leftPlayer = null;
            rightPlayer = null;

            form1.Show();
            this.Hide();
        }

        public void Form2_FormClosed(object sender, EventArgs e)
        {
            clearForm();

            Application.Exit();
        }

        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            setPlayerCoords(playerSpeed, e);
        }

        private void Form2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) clearForm();

            setPlayerCoords(0, e);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox3.Left = pictureBox3.Left + squareSpeedX;
            pictureBox3.Top = pictureBox3.Top - squareSpeedY;

            if ((pictureBox3.Left <= pictureBox1.Width + 15 && pictureBox1.Top <= pictureBox3.Top + pictureBox3.Height && pictureBox1.Bottom >= pictureBox3.Bottom - pictureBox3.Height) ||
                (pictureBox3.Left >= this.Size.Width - pictureBox3.Width - pictureBox3.Width - 20 && pictureBox2.Top <= pictureBox3.Top + pictureBox3.Height && pictureBox2.Bottom >= pictureBox3.Bottom - pictureBox3.Height))
            {
                squareSpeedX *= -1;
            }

            if (pictureBox3.Top <= 0 || pictureBox3.Top >= this.Size.Height - pictureBox3.Height - 30) squareSpeedY *= -1;

            if (pictureBox3.Left + pictureBox3.Width <= 0)
            {
                rightPlayer.scoreCount++;

                pictureBox3.Top = (int)((this.Height - pictureBox3.Height - 30)*0.5);
                pictureBox3.Left = (int)((this.Width - pictureBox3.Width - 20)*0.5);
            }
            else if (pictureBox3.Left + pictureBox3.Width >= this.Size.Width)
            {
                leftPlayer.scoreCount++;

                pictureBox3.Top = (int)((this.Height - pictureBox3.Height - 30) * 0.5);
                pictureBox3.Left = (int)((this.Width - pictureBox3.Width - 20) * 0.5);
            }

            label2.Text = leftPlayer.scoreCount.ToString() + ":" + rightPlayer.scoreCount.ToString();

            if (leftPlayer.scoreCount >= maxScoreCount)
            {
                clearForm();

                MessageBox.Show("Победил игрок слева.", "Результат игры", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                return;
            }
            else if (rightPlayer.scoreCount >= maxScoreCount)
            {
                clearForm();

                MessageBox.Show("Победил игрок справа.", "Результат игры", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                return;
            }

            if (leftPlayer.directionY != 0)
            {
                if (pictureBox1.Top + leftPlayer.directionY < 5)
                {
                    if (leftPlayer.isNPC) leftPlayer.directionY *= -1;
                    else leftPlayer.directionY = 5 - pictureBox1.Top;
                }
                else if (pictureBox1.Top + leftPlayer.directionY > this.Size.Height - pictureBox1.Size.Height - 45)
                {
                    if (leftPlayer.isNPC) leftPlayer.directionY *= -1;
                    else leftPlayer.directionY = this.Size.Height - pictureBox1.Size.Height - 45 - pictureBox1.Top;
                }

                pictureBox1.Top = pictureBox1.Top + leftPlayer.directionY;
            }

            if (rightPlayer.directionY != 0)
            {
                if (pictureBox2.Top + rightPlayer.directionY < 5)
                {
                    if (rightPlayer.isNPC) rightPlayer.directionY *= -1;
                    else rightPlayer.directionY = 5 - pictureBox2.Top;
                }
                else if (pictureBox2.Top + rightPlayer.directionY > this.Size.Height - pictureBox2.Size.Height - 45)
                {
                    if (rightPlayer.isNPC) rightPlayer.directionY *= -1;
                    else rightPlayer.directionY = this.Size.Height - pictureBox2.Size.Height - 45 - pictureBox2.Top;
                }

                pictureBox2.Top = pictureBox2.Top + rightPlayer.directionY;
            }
        }
    }
}
