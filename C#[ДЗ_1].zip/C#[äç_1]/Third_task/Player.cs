﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Third_task
{
    class Player
    {
        public int numberPosition;
        public int scoreCount = 0;
        public bool isNPC;

        public int directionY = 0;

        public Player(int numberPosition, int scoreCount, bool isNPC)
        {
            this.numberPosition = numberPosition;
            this.scoreCount = scoreCount;
            this.isNPC = isNPC;
        }
    }
}
