﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Third_task
{
    public partial class Form1 : Form
    {
        public int numberLevel = 0;
        public int numberPosition = 0;
        public int gamersCount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button_click(int gamersCount)
        {
            if (numberLevel == 0)
            {
                MessageBox.Show("Выберите уровень сложности!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }

            DialogResult result = MessageBox.Show("Для управления:\n[W], [S] - первый игрок( слева )\n[num_8], [num_2] - второй игрок( правый )\n[ESC] - выход\nПодтвердите ознакомление с информацией.", "Информация об управлении", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            if (result != DialogResult.OK) return;

            this.gamersCount = gamersCount;

            Form2 form2 = new Form2(){ Owner = this };
            form2.Show();

            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button_click(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button_click(2);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            numberLevel = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            numberLevel = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            numberLevel = 3;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            numberPosition = 0;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            numberPosition = 1;
        }
    }
}
