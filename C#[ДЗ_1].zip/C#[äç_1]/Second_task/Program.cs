﻿using System;

namespace Second_task
{
    enum BankType
    {
        Current,
        Credit,
        Deposit,
        Budget
    }

    struct BankData
    {
        public int number;
        public BankType type;
        public decimal balance;

        public BankData(int number, BankType type, decimal balance)
        {
            this.number = number;
            this.type = type;
            this.balance = balance;
        }

        public void Show()
        {
            Console.WriteLine("Информация о банковском счете:");
            Console.WriteLine("Номер: " + number.ToString() + ".");
            Console.WriteLine("Тип: " + type.ToString() + ".");
            Console.WriteLine("Баланс: $" + balance.ToString() + ".");
        }
    }

    enum HigherEducation
    {
        HarvardUniversity,
        MIT,
        StanfordUniversity,
        PrincetonUniversity,
        YaleUniversity
    }

    struct WorkerData
    {
        public string name;
        public string surname;
        public decimal wage;
        public HigherEducation university;

        public WorkerData(string name, string surname, decimal wage, HigherEducation university)
        {
            this.name = name;
            this.surname = surname;
            this.wage = wage;
            this.university = university;
        }

        public void Show()
        {
            Console.WriteLine("Информация о работнике:");
            Console.WriteLine("Имя: " + name + ".");
            Console.WriteLine("Фамилия: " + surname + ".");
            Console.WriteLine("Заработная плата: $" + wage.ToString() + ".");
            Console.WriteLine("ВУЗ: " + university.ToString() + ".");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("За один запуск консоли можно проверить только одно упражнение. Номера упражнений: 1, 2, 3.");
            Console.Write("Введите номер упражнения, который хотите проверить: ");

            try
            {
                int number = int.Parse(Console.ReadLine());
                if (number != 1 && number != 2 && number != 3)
                {
                    Console.WriteLine("Неверный номер упражнения!");
                    return;
                }

                Console.WriteLine("\nТестируем упражнение №" + number.ToString() + "...");

                if (number == 1)
                {
                    BankType value;
                    value = BankType.Current;

                    Console.WriteLine("Произвольное значение enum для банковского счета: " + value.ToString() + ".");
                }
                else if (number == 2)
                {
                    BankData user = new BankData(1, BankType.Deposit, 9570.5m);
                    user.Show();
                }
                else if (number == 3)
                {
                    WorkerData human = new WorkerData("John", "Lerner", 1000, HigherEducation.MIT);
                    human.Show();
                }
            }
            catch
            {
                Console.WriteLine("Непредвиденная ошибка! Попробуйте ещё раз.");
            }
        }
    }
}